#ifndef ORDER_H
#define ORDER_H

#include "Pizza.h"

class Order
{
    public:
        Order();
        virtual ~Order();

    private:
        static const int MAX_PIZZAS_ORDER = 10;

        Pizza pizzas[MAX_PIZZAS_ORDER];
};

#endif // ORDER_H
