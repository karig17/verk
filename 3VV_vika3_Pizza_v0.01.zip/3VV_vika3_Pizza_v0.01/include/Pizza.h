#ifndef PIZZA_H
#define PIZZA_H

#include "Topping.h"

class Pizza
{
    public:
        Pizza();
        virtual ~Pizza();

        Topping* getToppings();

        void addTopping(Topping topping);

    private:
        static const int MAX_TOPPINGS_PIZZA = 10;

        Topping toppings[MAX_TOPPINGS_PIZZA];
};

#endif // PIZZA_H
