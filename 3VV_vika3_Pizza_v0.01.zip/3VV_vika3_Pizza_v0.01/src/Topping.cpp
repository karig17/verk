#include "Topping.h"

Topping::Topping() {
    name[0] = '\0';
    //price = 0.0;
    pricingCategory = 0;
}

string Topping::getName() const{
    return name;
}

double Topping::getPrice() const{
    return 0;
    //return price;
}

int Topping::getPriceingCategory() const{
    return pricingCategory;
}

int Topping::getLines() const{
    ifstream fin;
    int recordCount = 0;
    fin.open("\\data\\Toppings.dat", ios::binary);
    if(fin.is_open()) {
        fin.seekg(0, fin.end);
        recordCount = fin.tellg() / sizeof(Topping);
        fin.seekg(0, fin.beg);
    }
    fin.close();
    return recordCount;
}

void Topping::setName(string newName) {
    strToCharArr(newName);
}

void Topping::setPrice(double newPrice) {
    //price = newPrice;
}

void Topping::setPriceingCategory(int newPriceCategory) {
    pricingCategory = newPriceCategory;
}


/// Converts strings to a character array.
void Topping::strToCharArr(string name) {
    for(unsigned int i = 0; i < name.size(); i++) {
        if(i == MAX_STRING_LENGTH -1) {
            break;
        }
        this->name[i] = name.at(i);
    }
    this->name[name.size()] = '\0';                   // Adds the esc.character after the end of the string.
    this->name[MAX_STRING_LENGTH - 1] = '\0';         // Adds the esc.character to the end of the charArray.
}

istream&  operator >> (istream& in, Topping& topping) {
    cout << "Enter topping name:   ";
    in >> topping.name;
    cout << "Enter price category: ";
    return in;
}

ostream& operator << (ostream& out, const Topping& topping) {
    out << '\t' << setw(topping.MAX_STRING_LENGTH) << topping.name << endl;
    return out;
}

ifstream& operator >> (ifstream& fin, Topping& topping) {
    int recordCount = topping.getLines();
    Topping* toppingsMaster = new Topping[recordCount];
    fin.read((char*)(toppingsMaster), (recordCount * sizeof(Topping)));
    fin.close();
    return fin;
}

ofstream& operator << (ofstream& fout, const Topping& topping) {
    fout.open("\\data\\Toppings.dat", ios::binary|ios::app);
    fout.write((char*)(&topping), sizeof(Topping));
    fout.close();
    return fout;
}
