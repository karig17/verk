#include "Order.h"

Order::Order()
{
    //ctor
}

Order::~Order()
{
    //dtor
}
