#include "Pizza.h"

Pizza::Pizza()
{

}

Pizza::~Pizza()
{
    //dtor
}


Topping* Pizza::getToppings() {
    return toppings;
}

void Pizza::addTopping(Topping topping) {
    for(int i = 0; i < MAX_TOPPINGS_PIZZA; i++) {
        if(toppings[i].getName() == "") {
            toppings[i].setName(topping.getName());
            toppings[i].setPriceingCategory(topping.getPriceingCategory());
        }
    }
}
