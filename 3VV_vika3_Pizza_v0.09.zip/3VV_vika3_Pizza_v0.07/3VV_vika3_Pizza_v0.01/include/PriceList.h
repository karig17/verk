#ifndef PRICELIST_H
#define PRICELIST_H


class PriceList
{
    public:
        PriceList();
        virtual ~PriceList();

    protected:

    private:
        static const int MAX_STRING_LENGTH = 16;

        char name[MAX_STRING_LENGTH];
        double price;
};

#endif // PRICELIST_H
