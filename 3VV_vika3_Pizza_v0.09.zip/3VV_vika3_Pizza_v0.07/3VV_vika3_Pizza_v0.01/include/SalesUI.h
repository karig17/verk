#ifndef SALESUI_H
#define SALESUI_H

#include "Order.h"

class SalesUI
{
    public:
        SalesUI();
        virtual ~SalesUI();

        void startUp();

    private:
};

#endif // SALESUI_H
