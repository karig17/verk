#include "MainUI.h"



#include <iostream>
using namespace std;

MainUI::MainUI()
{
    //ctor
}


void MainUI::startUI() {
    char c;

    while (c != 'q') {
    cout << "Please select a branch" << endl;
    cout << "1)\tAdministration" << endl;
    cout << "2)\tSales" << endl;
    cout << "3)\tBaking" << endl;
    cout << "4)\tDelivery" << endl;
    cout << "5)\tExit/Quit" << endl;
            cin >> c;
        if (c == '1') {
            AdminUI adminUI;
            adminUI.startUp();
        } else if (c == '2') {
            SalesUI salesUI;
            salesUI.startUp();
        } else if (c == '3') {
            BakerUI bakerUI;
            bakerUI.startUp();
        }
        else {
            if(c != 'q') {
                cout << "try again" << endl;
            }
        }
    }
    cout << "Shutting down" << endl;

}
