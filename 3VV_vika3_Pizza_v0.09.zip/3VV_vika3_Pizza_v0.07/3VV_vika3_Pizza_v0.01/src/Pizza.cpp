#include "Pizza.h"

Pizza::Pizza()
{
    name[0] = '\0';
    size = 0;
    type = 0;
    cheese = 0;
    sauce = 0;
}

Pizza::~Pizza()
{
    //dtor
}

double Pizza::getPrice() const{
    double num = 0.0;
    for(int i = 0; toppings[i].getName() != ""; i++) {
        num += toppings[i].getPriceingCategory() * 100;
    }
    num += 1000;
    return num;
}

int Pizza::getSize() const{
    return size;
}

Topping* Pizza::getToppings() {
    return toppings;
}

void Pizza::addTopping(Topping topping) {
    int counter = 0;
    while(counter < MAX_TOPPINGS_PIZZA) {
        if(toppings[counter].getName() == "") {
            toppings[counter].setName(topping.getName());
            toppings[counter].setPriceingCategory(topping.getPriceingCategory());
            break;
        }
        counter++;
    }
    if(counter == MAX_TOPPINGS_PIZZA - 1) {
        cout << "You have reached the maximum amount of toppings on this pizza." << endl;
    }
}

void Pizza::addToppings() {
    cout << endl << "Choose toppings: " << endl;

    int lines = toppings[0].getLines();
    Topping* toppingMaster = toppings[0].readFile();

    for(int i = 0; i < lines; i++) {
        cout << (i + 1) << toppingMaster[i];
    }

    int userInput[MAX_TOPPINGS_PIZZA];
    int counter = 0;
    cout << "Select toppings, press 0 to stop." << endl;

    while(counter < MAX_TOPPINGS_PIZZA) {
        cin >> userInput[counter];
        if(userInput[counter] == 0) {
            break;
        }
        counter++;
    }

    for(int i = 0; i < counter; i++) {
        addTopping(toppingMaster[userInput[i] - 1]);
    }
}

/// Converts strings to a character array.
void Pizza::strToCharArr(string nameStr) {
    for(unsigned int i = 0; i < nameStr.size(); i++) {
        if(i == MAX_PIZZA_LENGTH -1) {
            break;
        }
        this->name[i] = nameStr.at(i);
    }
    this->name[nameStr.size()] = '\0';                   // Adds the esc.character after the end of the string.
    this->name[MAX_PIZZA_LENGTH - 1] = '\0';         // Adds the esc.character to the end of the charArray.
}

istream&  operator >> (istream& in, Pizza& pizza) {
    string nameStr;
    cout << "Enter pizza name: ";
    in >> ws;
    getline(in, nameStr);
    pizza.strToCharArr(nameStr);
    cout << "Enter pizza sauce: ";
    in >> pizza.sauce;
    cout << "Enter pizza toppings; ";
    pizza.addToppings();
    return in;
}

ostream&  operator << (ostream& out, const Pizza& pizza) {
    if(pizza.name[0] == '\0') {
        out << "Custom pizza: " << endl;
    } else {
        out << pizza.name << ": " << endl;
    }
    for(int i = 0; i < pizza.MAX_TOPPINGS_PIZZA; i++) {
        if(pizza.toppings[i].getName() == "") {
            break;
        } else {
            out << pizza.toppings[i];
        }
    }
    out << pizza.getPrice() << endl;
    return out;
}

ifstream& operator >> (ifstream& fin, Pizza& pizza) {
    fin.open("Pizza.dat", ios::binary);
    fin.read((char*)(&pizza), sizeof(Pizza));
    fin.close();
    return fin;
}

ofstream& operator << (ofstream& fout, const Pizza& pizza) {
    fout.open("Pizza.dat", ios::binary|ios::app);
    fout.write((char*)(&pizza), sizeof(Pizza));
    fout.close();
    return fout;
}
