#include "SalesUI.h"

SalesUI::SalesUI()
{
    //ctor
}
void SalesUI::startUp() {
    cout << "wanna create order? (y/n)" << endl;
    char c;
    cin >> c;

    if (c == 'y') {
        Order order;
        order.pizzaOrders();
        order.setDelMethod();
        order.setAddress();
        order.setComments();
    }
    while (c != 'n') {
        cout << "wanna create another order? (y/n)" << endl;
        cin >> c;
    if (c == 'y') {
        Order order2;
        order2.pizzaOrders();
        order2.setDelMethod();
        order2.setAddress();
        order2.setComments();;
        break;
        }
    }
}

SalesUI::~SalesUI()
{
    //dtor
}
