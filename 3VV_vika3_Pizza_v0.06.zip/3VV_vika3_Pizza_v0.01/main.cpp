#include <iostream>

#include "MainUI.h"

#include "Pizza.h"
using namespace std;


int main()
{
    MainUI mainUI;

    mainUI.startUI();

    return 0;



    ofstream fout;

    Topping topping;

    int toppingMasterSize = topping.getLines();

    Topping* toppingMaster = topping.readFile();

    for(int i = 0; i < toppingMasterSize; i++) {
        cout << (i + 1) << ")" << toppingMaster[i];
    }





    return 0;

    char userInput;
    do {
        userInput = 'n';
        cout << "Add a topping: " << endl;
        Topping Topping;
        cin >> Topping;
        fout << Topping;
        cout << "Continue? (y/n) ";
        cin >> userInput;
    } while(userInput == 'y');


    //return 0;

    Pizza pizza;
    int toppingCount;
    cout << "Number of toppings: ";
    cin >> toppingCount;

    for(int i = 0; i < toppingCount; i++) {
        Topping topping;
        cin >> topping;
        pizza.addTopping(topping);
    }

    cout << pizza;

    return 0;


}



