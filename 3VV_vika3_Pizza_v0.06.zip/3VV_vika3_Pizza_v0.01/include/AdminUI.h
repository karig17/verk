#include <iostream>
using namespace std;

#ifndef ADMINUI_H
#define ADMINUI_H


class AdminUI
{
    public:
        AdminUI();
        virtual ~AdminUI();
        void startUp();


    protected:

    private:
};

#endif // ADMINUI_H
