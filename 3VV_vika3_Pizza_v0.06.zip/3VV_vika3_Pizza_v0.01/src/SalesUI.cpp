#include "..\include\SalesUI.h"

SalesUI::SalesUI()
{
    //ctor
}
void SalesUI::startUp() {
    cout << "wanna create order? (y/n)" << endl;
    char c;
    cin >> c;

    if (c == 'y') {
        Order order;
//        order.makeOrder(order);
    }
    while (c != 'n') {
    cout << "wanna create another order? (y/n)" << endl;
    cin >> c;
    if (c == 'y') {
        Order order2;
//        order2.makeOrder(order2);
        break;
    }
    }
}

SalesUI::~SalesUI()
{
    //dtor
}
