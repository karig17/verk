#include "SuperHero.h"

SuperHero::SuperHero() {
    heroName = "";
    heroAge = 0;
    heroPowerChar = 'n';
}

SuperHero::SuperHero(string name, int age, char power) {
    heroName = name;
    heroAge = age;
    heroPowerChar = power;
}

string SuperHero::getName() {
    return heroName;
}

int SuperHero::getAge() {
    return heroAge;
}

char SuperHero::getPowerChar() {
    return heroPowerChar;
}

void SuperHero::setName(string newName) {
    heroName = newName;
}

void SuperHero::setAge(int newAge) {
    heroAge = newAge;
}

void SuperHero::setPowerChar(char newPowerChar) {
    heroPowerChar = newPowerChar;
}

istream& operator >> (istream& in, SuperHero& hero) {
    ofstream fout;
    fout.open("SuperHeros.txt");
    fout << hero.heroName << hero.heroAge << hero.heroPowerChar;
    return in;
}

ostream& operator << (ostream& out, const SuperHero& hero) {
    ifstream fin;
    fin.open("SuperHeros.txt");
    fin >> hero.heroName >> hero.heroAge >> hero.heroPowerChar;
    cout << hero.heroName << " (" << hero.heroAge << "): " << hero.heroPowerChar;
}

