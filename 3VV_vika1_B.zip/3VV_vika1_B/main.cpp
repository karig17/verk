#include <iostream>
#include "SuperHero.h"
using namespace std;

int main()
{
    SuperHero hero;

    return 0;
}
