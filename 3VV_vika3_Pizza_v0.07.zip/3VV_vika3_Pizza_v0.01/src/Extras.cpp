#include "..\include\Extras.h"

Extras::Extras()
{
    name[0] = '\0';
    price  = 0.0;
}

string Extras::getName() const{
    return name;
}

double Extras::getPrice() const{
    return 0;
    //return price;
}

int Extras::getLines() const{
    ifstream fin;
    int recordCount = 0;
    fin.open("Extras.dat", ios::binary);
    if(fin.is_open()) {
        fin.seekg(0, fin.end);
        recordCount = fin.tellg() / sizeof(Extras);
        fin.seekg(0, fin.beg);
    }
    fin.close();
    return recordCount;
}

void Extras::setName(string newName) {
    strToCharArr(newName);
}

void Extras::setPrice(double newPrice) {
    price = newPrice;
}

/// Converts strings to a character array.
void Extras::strToCharArr(string nameStr) {
    for(unsigned int i = 0; i < nameStr.size(); i++) {
        if(i == MAX_STRING_LENGTH -1) {
            break;
        }
        this->name[i] = nameStr.at(i);
    }
    this->name[nameStr.size()] = '\0';                   // Adds the esc.character after the end of the string.
    this->name[MAX_STRING_LENGTH - 1] = '\0';         // Adds the esc.character to the end of the charArray.
}

Extras* Extras::readFile() {
    ifstream fin;
    Extras* extrasMaster = 0;
    fin.open("Extras.dat");
    if(fin.is_open()) {
        fin.seekg(0, fin.end);
        int recordCount = fin.tellg() / sizeof(Extras);
        fin.seekg(0, fin.beg);
        extrasMaster = new Extras[recordCount];

        fin.read((char*)(extrasMaster), (recordCount * sizeof(Extras)));
    } else {
        cout << "Unable to read the extra list." << endl;
    }
    fin.close();
    return extrasMaster;
}


istream&  operator >> (istream& in, Extras& extra) {
    string nameStr;
    cout << "Enter extra's name: ";
    in >> ws;
    getline(in, nameStr);
    extra.strToCharArr(nameStr);
    cout << "Enter price:        ";
    in >> extra.price;
    return in;
}

ostream& operator << (ostream& out, const Extras& extra) {
    out << '\t' << setw(extra.MAX_STRING_LENGTH) << left << extra.name << " | Price: " << extra.price << endl;
    return out;
}

ifstream& operator >> (ifstream& fin, Extras& extra) {
    fin.open("Extras.dat");
    if(fin.is_open()) {
        fin.seekg(0, fin.end);
        int recordCount = fin.tellg() / sizeof(Extras);
        fin.seekg(0, fin.beg);
        Extras* extrasMaster = new Extras[recordCount];

        fin.read((char*)(extrasMaster), (recordCount * sizeof(Extras)));
    } else {
        cout << "Unable to read the extra list." << cout;
    }
    fin.close();
    return fin;
}

ofstream& operator << (ofstream& fout, const Extras& extra) {
    fout.open("Extras.dat", ios::binary|ios::app);
    fout.write((char*)(&extra), sizeof(Extras));
    fout.close();
    return fout;
}
