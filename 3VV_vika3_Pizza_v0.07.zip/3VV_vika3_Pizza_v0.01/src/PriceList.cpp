#include "PriceList.h"

PriceList::PriceList()
{
    //ctor
}

PriceList::~PriceList()
{
    //dtor
}
