#include "Pizza.h"

Pizza::Pizza()
{

}

Pizza::~Pizza()
{
    //dtor
}


Topping* Pizza::getToppings() {
    return toppings;
}

void Pizza::addTopping(Topping topping) {
    int counter = 0;
    for(int i = 0; i < MAX_TOPPINGS_PIZZA; i++) {
        if(toppings[i].getName() == "") {
            toppings[i].setName(topping.getName());
            toppings[i].setPriceingCategory(topping.getPriceingCategory());
            break;
        } else {
            counter++;
        }
    }
    if(counter == MAX_TOPPINGS_PIZZA) {
        cout << "You have reached the maximum amount of toppings on this pizza." << endl;
    }
}


istream&  operator >> (istream& in, Pizza& pizza) {
    return in;
}

ostream&  operator << (ostream& out, const Pizza& pizza) {
    cout << "pizza.name" << ": " << endl;
    for(int i = 0; i < pizza.MAX_TOPPINGS_PIZZA; i++) {
        if(pizza.toppings[i].getName() == "") {
            break;
        } else {
            cout << pizza.toppings[i];
        }

    }
    return out;
}

ifstream& operator >> (ifstream& fin, Pizza& pizza) {
    fin.open("Pizza.dat", ios::binary);
    fin.read((char*)(&pizza), sizeof(Pizza));
    fin.close();
    return fin;
}

ofstream& operator << (ofstream& fout, const Pizza& pizza) {
    fout.open("Pizza.dat", ios::binary|ios::app);
    fout.write((char*)(&pizza), sizeof(Pizza));
    fout.close();
    return fout;
}
