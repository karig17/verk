#ifndef ADMINUI_H
#define ADMINUI_H

#include "Extras.h"
#include "Topping.h"

#include <iostream>
using namespace std;



class AdminUI
{
    public:
        AdminUI();
        virtual ~AdminUI();

        void startUp();
        //1
        void addToppings();
        //3
        void addExtras();
        //4
        //5

    private:
};

#endif // ADMINUI_H
