#include <iostream>
#include "Order.h"

using namespace std;

#ifndef SALESUI_H
#define SALESUI_H


class SalesUI
{
    public:
        SalesUI();
        virtual ~SalesUI();
        void startUp();

    protected:

    private:
};

#endif // SALESUI_H
