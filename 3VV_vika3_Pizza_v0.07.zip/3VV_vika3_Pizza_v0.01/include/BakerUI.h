#ifndef BAKERUI_H
#define BAKERUI_H


class BakerUI
{
    public:
        BakerUI();
        void startUp();
        virtual ~BakerUI();

    protected:

    private:
};

#endif // BAKERUI_H
