#ifndef PIZZASIZE_H
#define PIZZASIZE_H


class PizzaSize
{
    public:
        PizzaSize();

    protected:

    private:
};

#endif // PIZZASIZE_H
