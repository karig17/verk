#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main() {
  ifstream fin;
  char c,input;
  fin.open("bla.txt");
  do{
    if (fin.is_open()) {
        for (int i = 0; i < 10; i++) {
          fin >> c;
          cout << c << endl;
        }
        do {
            cout <<"halda afram?(y/n):";
            cin >>input;
            if(input == 'n') {
                break;
            }
        }while(input != 'n' && input !='y');
    }
  }while(input == 'y');
  fin.close();

}
