#ifndef PRICELIST_H
#define PRICELIST_H


class PriceList
{
    public:
        PriceList();
        virtual ~PriceList();

    protected:

    private:
};

#endif // PRICELIST_H
