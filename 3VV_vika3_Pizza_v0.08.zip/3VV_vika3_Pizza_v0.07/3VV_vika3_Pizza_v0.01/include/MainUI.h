#ifndef MAINUI_H
#define MAINUI_H

#include "..\include\AdminUI.h"
#include "..\include\BakerUI.h"
#include "..\include\SalesUI.h"

using namespace std;

class MainUI
{
    public:
        MainUI();

        void startUI();

    private:
};

#endif // MAINUI_H
