#ifndef PIZZA_H
#define PIZZA_H

#include "Topping.h"

class Pizza
{
    public:
        Pizza();
        virtual ~Pizza();

        static const int MAX_TOPPINGS_PIZZA = 10;

        Topping* getToppings();

        void addTopping(Topping topping);

        friend istream&  operator >> (istream& in, Pizza& pizza);
        friend ostream&  operator << (ostream& out, const Pizza& pizza);
        friend ifstream& operator >> (ifstream& fin, Pizza& pizza);
        friend ofstream& operator << (ofstream& fout, const Pizza& pizza);


    private:
        static const int MAX_PIZZA_LENGTH = 24;

        char name[MAX_PIZZA_LENGTH];
        Topping toppings[MAX_TOPPINGS_PIZZA];


};

#endif // PIZZA_H
