#include "PizzaSize.h"

PizzaSize::PizzaSize()
{
    //ctor
}
