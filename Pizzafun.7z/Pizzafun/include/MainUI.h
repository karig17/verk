#include <iostream>
#include "SalesUI.h"

using namespace std;

#ifndef MAINUI_H
#define MAINUI_H


class MainUI
{
    public:
        MainUI();
        virtual ~MainUI();
        void startUp();

    protected:

    private:
};

#endif // MAINUI_H
