#include "Topping.h"
#ifndef PIZZA_H
#define PIZZA_H
static const int MAX_TOPPINGS = 10;

class Pizza
{
    public:
        Pizza();
        virtual ~Pizza();

    protected:

    private:
        int numberOfToppings;
        char pizzaSize;
        Topping toppArr[MAX_TOPPINGS];

};

#endif // PIZZA_H
