#include <iostream>
using namespace std;

#ifndef TOPPING_H
#define TOPPING_H


class Topping
{
    public:
        Topping();
        virtual ~Topping();

    protected:

    private:
        string name;
        char prize;
};

#endif // TOPPING_H
