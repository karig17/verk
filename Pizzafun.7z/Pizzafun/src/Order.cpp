#include "Order.h"

Order::Order()
{
    //ctor
}
void Order::makeOrder(Order order) {
    int n;
    cout << "how many pizzas? ";
    cin >> n;
    for (int i = 0; i < n; i++) {


    }

}

Order::~Order()
{
    //dtor
}
