#include "Topping.h"

Topping::Topping()
{
    //ctor
}

Topping::~Topping()
{
    //dtor
}
