#include "MainUI.h"

MainUI::MainUI()
{
    //ctor
}
void MainUI::startUp() {
    cout << "type 1 for sales" << endl;
    cout << "type q to quit" << endl;
    char c;
    cin >> c;
    while (c != 'q') {
        if (c == '1') {
            SalesUI salesUI;
            salesUI.startUp();
            break;


        }
        else cout << "try again" << endl;
    }
}
MainUI::~MainUI()
{
    //dtor
}
