#include "MainUI.h"


using namespace std;

int main()
{
    MainUI mainUI;
    mainUI.startUp();
    return 0;
}
