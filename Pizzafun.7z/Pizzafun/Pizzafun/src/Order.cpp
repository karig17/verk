#include "../include/Order.h"

Order::Order()
{
    //ctor
}
void Order::makeOrder(Order order) {
    int n;
    cout << "how many pizzas? ";
    cin >> n;
    Pizza arr[MAX_IN_ORDER];
    for (int i = 0; i < n; i++) {

    }

}

Order::~Order()
{
    //dtor
}
