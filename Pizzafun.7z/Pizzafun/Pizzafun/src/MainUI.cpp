#include "..\include\MainUI.h"
#include "..\include\AdminUI.h"

MainUI::MainUI()
{
    //ctor
}
void MainUI::startUp() {
    cout << "type 1 for sales" << endl;
    cout << "type 2 for baker" << endl;
    cout << "type password for admin" << endl;
    cout << "type q to quit" << endl;
    char c;

    while (c != 'q') {
            cin >> c;
        if (c == '1') {
            SalesUI salesUI;
            salesUI.startUp();
            break;
        }
        else if (c == '2') {
            BakerUI bakerUI;
            bakerUI.startUp();
        }
        else if (c == '7') {
            AdminUI adminUI;
            adminUI.startUp();
        }


        else cout << "try again" << endl;
    }
}
MainUI::~MainUI()
{
    //dtor
}
