#include "..\include\Pizza.h"

Pizza::Pizza()
{

}

Pizza::~Pizza()
{
    //dtor
}


Topping* Pizza::getToppings() {
    return toppings;
}

void Pizza::addTopping(Topping topping) {
    int counter;
    for(int i = 0; i < MAX_TOPPINGS_PIZZA; i++) {
        if(toppings[i].getName() == "") {
            toppings[i].setName(topping.getName());
            toppings[i].setPriceingCategory(topping.getPriceingCategory());
            break;
        } else {
            counter++;
        }
    }
    if(counter == MAX_TOPPINGS_PIZZA) {
        cout << "You have reached the maximum amount of toppings on this pizza." << endl;
    }
}


istream&  operator >> (istream& in, Pizza& pizza) {
    return in;
}

ostream&  operator << (ostream& out, const Pizza& pizza) {
    cout << "pizza.name" << ": " << endl;
    for(int i = 0; i < pizza.MAX_TOPPINGS_PIZZA; i++) {
        if(pizza.toppings[i].getName() == "") {
            break;
        } else {
            cout << pizza.toppings[i];
        }

    }
    return out;
}

ifstream& operator >> (ifstream& fin, Pizza& pizza) {
    return fin;
}

ofstream& operator << (ofstream& fout, const Pizza& pizza) {
    return fout;
}
