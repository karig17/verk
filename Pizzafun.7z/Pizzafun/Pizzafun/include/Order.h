#include "..\include\Pizza.h"
#include "..\include\Extras.h"
#include <iostream>

using namespace std;


#ifndef ORDER_H
#define ORDER_H
const static int MAX_IN_ORDER = 10;

class Order
{
    public:
        Order();
        virtual ~Order();
        void makeOrder(Order order);



    protected:

    private:
        Pizza pizzaArr[MAX_IN_ORDER];
        Extras extraArr[MAX_IN_ORDER];
        bool delivered;
        string pizzaPlace;

};

#endif // ORDER_H
