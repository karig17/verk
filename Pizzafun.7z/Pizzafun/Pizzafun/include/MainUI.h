#include <iostream>
#include "..\include\SalesUI.h"
#include "..\include\BakerUI.h"

using namespace std;

#ifndef MAINUI_H
#define MAINUI_H


class MainUI
{
    public:
        MainUI();
        virtual ~MainUI();
        void startUp();

    protected:

    private:
};

#endif // MAINUI_H
