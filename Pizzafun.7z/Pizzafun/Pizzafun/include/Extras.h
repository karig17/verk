#include <iostream>

using namespace std;

#ifndef EXTRAS_H
#define EXTRAS_H


class Extras
{
    public:
        Extras();
        virtual ~Extras();

    protected:

    private:
        string name;
        int prize;
};

#endif // EXTRAS_H
