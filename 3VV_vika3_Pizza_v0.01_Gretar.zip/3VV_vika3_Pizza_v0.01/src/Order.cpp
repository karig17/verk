#include "Order.h"

Order::Order()
{

}

Order::~Order()
{
    //dtor
}
void Order::pizzaOrders() {
    cout <<"choose toppings:";
    char cont;
    int i = 0;
    do{
    Topping topping;
    pizzas[i].addTopping(topping);
    cout <<"add another pizza to the order? (y/n):";
    cin >>cont;
    if(cont == 'y') {
        i++;
    }
    }while(cont == 'y');
    cout <<"Your pizzas: "<< endl;
    for(int j = 0; j < i; j++) {
        cout << pizzas[j];
    }

}
void Order::setDelMethod() {
    char delivery;
    cout <<"pick up or delivery?(p/d): ";
    cin >>delivery;
    _delMethod= delivery;
}
void Order::setAddress() {
    if(_delMethod == 'd') {
        char address[MAX_ADDRESS_LENGTH];
        for(int i = 0; i < MAX_ADDRESS_LENGTH; i++) {
            cin >>address[i];
        }
        *_address = *address;
    }
}
void Order::setComments() {
    char svar;
    char comments[MAX_COMMENT_LENGTH];
    cout <<"any comments?(y/n): ";
    cin >>svar;
    if(svar == 'y') {
        cout <<"comments :";
        for(int i = 0; i < MAX_COMMENT_LENGTH; i++) {
            cin >> comments[i];
        }
    }
    *_comments = *comments;
}
