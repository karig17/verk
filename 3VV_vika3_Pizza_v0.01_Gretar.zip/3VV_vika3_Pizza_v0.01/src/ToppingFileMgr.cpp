#include "ToppingFileMgr.h"

ToppingFileMgr::ToppingFileMgr()
{
    //ctor
}

ToppingFileMgr::~ToppingFileMgr()
{
    //dtor
}
