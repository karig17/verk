#include <iostream>
#include "SuperHero.h"
using namespace std;

int main()
{
    SuperHero hero;

    hero("Test", 20, 'n');

    ifstream fin;
    ofstream fout;

    fin >> hero;
    fout << hero;
    cout << hero;

    return 0;
}
