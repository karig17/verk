#include "Order.h"

Order::Order()
{

}

Order::~Order()
{
    //dtor
}

void Order::pizzaOrders() {
    cout <<"choose toppings:" <<endl;
    char cont;
    int i = 0;
    do {
        Topping topping;
        pizzas[i].addTopping(topping);
        cout <<"add another pizza to the order? (y/n):";
        cin >>cont;
        if(cont == 'y') {
            i++;
        }
    } while(cont == 'y');
    cout <<"Your pizzas: "<< endl;
    for(int j = 0; j < i; j++) {
        cout << pizzas[j];
    }

}
void Order::setDelMethod() {
    char delivery;
    cout <<"pick up or delivery?(p/d): ";
    cin >>delivery;
    _delMethod= delivery;
}
void Order::setAddress() {
    if(_delMethod == 'd') {
        string address;
        cout <<"address: ";
        cin >>ws;
        getline(cin, address);
        for(unsigned int i = 0; i < address.size(); i++) {
            if(i == MAX_ADDRESS_LENGTH -1) {
                break;
            }
            _address[i] = address.at(i);
        }
        _address[address.size()] = '\0';
        _address[MAX_ADDRESS_LENGTH -1] = '\0';
    }
}
void Order::setComments() {
    char svar;
    string comment;
    cout <<"any comments?(y/n): ";
    cin >>svar;
    if(svar == 'y') {
        cout <<"comments :";
        cin >>ws;
        getline(cin, comment);
        for(unsigned int i = 0; i < comment.size(); i++) {
            if(i == MAX_COMMENT_LENGTH -1)
                break;
            _comments[i] = comment.at(i);
        }
        _comments[comment.size()] = '\0';
        _comments[MAX_COMMENT_LENGTH - 1] = '\0';
    }
}
