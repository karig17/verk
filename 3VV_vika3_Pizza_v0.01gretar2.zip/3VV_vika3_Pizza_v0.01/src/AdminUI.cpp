#include "AdminUI.h"

AdminUI::AdminUI()
{
    //ctor
}

AdminUI::~AdminUI()
{
    //dtor
}

void AdminUI::startUp() {
    cout << "type 1 to add size" << endl;
    cout << "type 2 to add topping" << endl;
    cout << "type 3 to add pizza to menu" << endl;
    cout << "type 4 to add extras" << endl;
    cout << "type 5 to add prize" << endl;
    cout << "type 6 to add pizzaplace" << endl;
    cout << "type q to add quit" << endl;
    char c;

    while(c != 'q') {
        cin >> c;
            if (c == 1) {
                    break;
            }
            if (c == 2) {
            }
            if (c == 3) {
            }
            if (c == 4) {
            }
            if (c == 5) {
            }
            if (c == 6) {
            }
    }


}
