#ifndef MAINUI_H
#define MAINUI_H

#include "AdminUI.h"
#include "BakerUI.h"
#include "SalesUI.h"

using namespace std;

class MainUI
{
    public:
        MainUI();

        void startUI();

    private:
};

#endif // MAINUI_H
