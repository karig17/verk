#ifndef TOPPINGFILEMGR_H
#define TOPPINGFILEMGR_H


class ToppingFileMgr
{
    public:
        ToppingFileMgr();
        virtual ~ToppingFileMgr();

    protected:

    private:
};

#endif // TOPPINGFILEMGR_H
