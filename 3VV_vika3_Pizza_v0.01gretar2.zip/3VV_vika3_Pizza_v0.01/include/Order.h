#ifndef ORDER_H
#define ORDER_H

#include "Pizza.h"

class Order
{
    public:
        Order();
        virtual ~Order();
        void pizzaOrders();
        void setDelMethod();
        void setAddress();
        /// vantar extras
        void setComments();


    private:
        static const int MAX_PIZZAS_ORDER = 10;
        static const int MAX_ADDRESS_LENGTH = 30;
        static const int MAX_COMMENT_LENGTH = 50;

        Pizza pizzas[MAX_PIZZAS_ORDER];
        char _address[MAX_ADDRESS_LENGTH];
        char _delMethod;
        /// vantar extras
        int _totalPirce;
        char _paymentStatus;
        char _comments[MAX_COMMENT_LENGTH];

};

#endif // ORDER_H
