#include <iostream>

#include "MainUI.h"

#include "Pizza.h"
#include "Extras.h"
using namespace std;


int main()
{
    ifstream fin;
    ofstream fout;

    MainUI mainUI;

    mainUI.startUI();

    return 0;



    Topping topping;
/*
    int toppingMasterSize = topping.getLines();

    Topping* toppingMaster = topping.readFile();

    for(int i = 0; i < toppingMasterSize; i++) {
        cout << (i + 1) << ")" << toppingMaster[i];
    }

*/
    Extras extra;

    cin >> extra;
    fout << extra;

    int extraMasterSize = extra.getLines();

    Extras* extraMaster = extra.readFile();

    for(int i = 0; i < extraMasterSize; i++) {
        cout << (i + 1) << ")" << extraMaster[i];
    }

    return 0;


    //return 0;

    char userInput;
    Topping Topping;
    do {
        userInput = 'n';
        cout << "Add a topping: " << endl;
        cin >> Topping;
        fout << Topping;
        cout << "Continue? (y/n) ";
        cin >> userInput;
    } while(userInput == 'y');


    //return 0;

    Pizza pizza;
    int toppingCount;
    cout << "Number of toppings: ";
    cin >> toppingCount;

    for(int i = 0; i < toppingCount; i++) {
        cin >> topping;
        pizza.addTopping(topping);
    }

    cout << pizza;

    return 0;


}



