#include "DataBase.h"

DataBase::DataBase()
{
    //ctor
}

DataBase::~DataBase()
{
    //dtor
}
