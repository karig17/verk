#include "Order.h"

Order::Order()
{
    Topping topping;
    Extras extra;

    _address[0] = '\0';
    _delMethod = false;
    _totalPirce = 0;
    _paymentStatus = 0;
    _comments[0] = '\0';

}

Order::~Order()
{
    //dtor
}

double Order::getPrice() {
    double num = 0.0;
    for(int i = 0; pizzas[i].getSize() != 0; i++) {
        num += pizzas[i].getPrice();
    } if (_delMethod) {
        num += 1000;
    }
    return num;
}

void Order::pizzaOrders() {
    Topping topping;
    char cont;
    int i = 0;

    do {
        pizzas[i].addSause();
        pizzas[i].addToppings();

        cout <<"add another pizza to the order? (y/n):";
        cin >>cont;
        if(cont == 'y') {
            i++;
        }
    } while(cont == 'y');

    cout <<"Your pizzas: "<< endl;
    for(int j = 0; j <= i; j++) {
        cout << pizzas[j];
    }

}

void Order::setDelMethod() {
    char delivery;
    cout <<"pick up or delivery? (p/d): ";
    cin >> delivery;
    if(delivery == 'd') {
        _delMethod = delivery;
    }
}

void Order::setAddress() {
    if(_delMethod) {
        string address;
        cout <<"address: ";
        cin >>ws;
        getline(cin, address);
        for(unsigned int i = 0; i < address.size(); i++) {
            if(i == MAX_ADDRESS_LENGTH -1) {
                break;
            }
            _address[i] = address.at(i);
        }
        _address[address.size()] = '\0';
        _address[MAX_ADDRESS_LENGTH -1] = '\0';
    }
}

void Order::setComments() {
    char svar;
    string comment;
    cout <<"any comments?(y/n): ";
    cin >>svar;
    if(svar == 'y') {
        cout <<"comments :";
        cin >>ws;
        getline(cin, comment);
        for(unsigned int i = 0; i < comment.size(); i++) {
            if(i == MAX_COMMENT_LENGTH -1)
                break;
            _comments[i] = comment.at(i);
        }
        _comments[comment.size()] = '\0';
        _comments[MAX_COMMENT_LENGTH - 1] = '\0';
    }
}
