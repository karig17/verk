#include "..\include\BakerUI.h"

BakerUI::BakerUI()
{
    //ctor
}
void BakerUI::startUp() {

}

BakerUI::~BakerUI()
{
    //dtor
}
