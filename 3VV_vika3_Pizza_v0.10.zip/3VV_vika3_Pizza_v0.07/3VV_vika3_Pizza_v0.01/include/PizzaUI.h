#ifndef PIZZAUI_H
#define PIZZAUI_H


class PizzaUI
{
    public:
        PizzaUI();
        virtual ~PizzaUI();

    protected:

    private:
};

#endif // PIZZAUI_H
