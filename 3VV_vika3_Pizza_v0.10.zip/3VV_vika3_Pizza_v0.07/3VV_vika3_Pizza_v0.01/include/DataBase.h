#ifndef DATABASE_H
#define DATABASE_H

#include "Extras.h"
#include "Pizza.h"
#include "PizzaSauce.h"
#include "PizzaSize.h"
#include "Topping.h"

class DataBase
{
    public:
        DataBase();
        ~DataBase();
/*
        Extras* extraMaster;
        Pizza* pizzaMaster;
        PizzaSauce* sauceMaster;
        PizzaSize* sizeMaster;
        Topping* toppingMaster;

        void display

    private:
        int extraID();
        int pizzaID();
        int orderID();
        int sauceID();
        int sizeID();
        int toppingID();

*/
};

#endif // DATABASE_H
