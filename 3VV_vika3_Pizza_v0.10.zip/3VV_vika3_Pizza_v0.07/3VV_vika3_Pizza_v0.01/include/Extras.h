#ifndef EXTRAS_H
#define EXTRAS_H

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;


class Extras
{
    public:
        Extras();

        string getName() const;
        double getPrice() const;
        int getLines() const;

        void setName(string newName);
        void setPrice(double newPrice);
        void setPriceingCategory(int newPriceCategory);

        Extras* readFile();

        friend istream&  operator >> (istream& in, Extras& extra);
        friend ostream&  operator << (ostream& out, const Extras& extra);
        friend ifstream& operator >> (ifstream& fin, Extras& extra);
        friend ofstream& operator << (ofstream& fout, const Extras& extra);

    private:
        static const int MAX_STRING_LENGTH = 24;

        char name[MAX_STRING_LENGTH];
        double price;

        void strToCharArr(string name);
};

#endif // TOPPING_H
