#include <iostream>

#include "MainUI.h"

#include "Pizza.h"

using namespace std;

int main()
{
    Pizza pizza;
    int toppingCount;
    cout << "Number of toppings: ";
    cin >> toppingCount;

    for(int i = 0; i < toppingCount; i++) {
        Topping topping;
        cin >> topping;
        pizza.addTopping(topping);
    }

    cout << pizza;

    return 0;

    MainUI mainUI;

    mainUI.startUI();

    return 0;
}



