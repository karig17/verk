#ifndef TOPPING_H
#define TOPPING_H

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
using namespace std;


class Topping
{
    public:
        Topping();

        string getName() const;
        double getPrice() const;
        int getPriceingCategory() const;
        int getLines() const;

        void setName(string newName);
        void setPrice(double newPrice);
        void setPriceingCategory(int newPriceCategory);

        friend istream&  operator >> (istream& in, Topping& topping);
        friend ostream&  operator << (ostream& out, const Topping& topping);
        friend ifstream& operator >> (ifstream& fin, Topping& topping);
        friend ofstream& operator << (ofstream& fout, const Topping& topping);

    private:
        static const int MAX_STRING_LENGTH = 24;

        char name[MAX_STRING_LENGTH];
        //double price;
        int pricingCategory;

        void strToCharArr(string name);


};

#endif // TOPPING_H
